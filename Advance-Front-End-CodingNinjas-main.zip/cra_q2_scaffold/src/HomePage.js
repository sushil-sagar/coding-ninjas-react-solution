// Complete the HomePage Component and export it

function HomePage() {
  return (
    <div className="Homepage">
      <h1>HomePage</h1>
    </div>
  );
}
export default HomePage;