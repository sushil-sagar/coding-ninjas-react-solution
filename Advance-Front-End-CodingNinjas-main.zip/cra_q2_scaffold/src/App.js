import "./styles.css";
import HomePage from "./HomePage";
import Form from "./Form";
export default function App() {
  return <div className="App">
    <HomePage/>
    <Form/>
  </div>;
}
