import React, { Component } from 'react';

export default class Button extends Component {
  render() {
    return (
        <div>
            <button className='button'>Hover Over Me !</button>
        </div>
    )
  }
}