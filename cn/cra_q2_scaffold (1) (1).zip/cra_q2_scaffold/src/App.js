import "./styles.css";
import HomePage from "./HomePage";

export default function App() {
  return <div className="App">
    <HomePage/>
  </div>;
}
