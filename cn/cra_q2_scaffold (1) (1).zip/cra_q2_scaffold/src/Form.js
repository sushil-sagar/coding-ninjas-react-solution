// Complete the Form Component and export it
import { name, email } from "./HomePage";

function handleSubmit(e) {
   e.preventDefault()
 }
const Form = () => (
  <>
    <div>
      <form onSubmit={handleSubmit}>
        
        <h3>Login Page</h3>
        <input placeholder="Name" type="name" value={name} />
        <br />
        <br />
        <input placeholder="Email" type="email" value={email} />
        <br />
        <br />
        <button type="Submit">Login</button>
        
      </form>
    </div>
  </>
);

export default Form;
